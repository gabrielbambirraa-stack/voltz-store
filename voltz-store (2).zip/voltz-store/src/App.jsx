import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Benefits from './components/Benefits.jsx';
import Categories from './components/Categories.jsx';
import Products from './components/Products.jsx';
import About from './components/About.jsx';
import Newsletter from './components/Newsletter.jsx';
import Footer from './components/Footer.jsx';
import CartDrawer from './components/CartDrawer.jsx';
import SearchOverlay from './components/SearchOverlay.jsx';
import { CheckIcon } from './components/Icons.jsx';
import { products as allProducts } from './data/products.js';
import { normalize } from './utils/helpers.js';
import useCart from './hooks/useCart.js';

export default function App() {
  const { items, count, total, addItem, removeItem, changeQty, clear } = useCart();
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('todos');
  const [sort, setSort] = useState('relevancia');
  const [toast, setToast] = useState({ text: '', visible: false });
  const [bump, setBump] = useState(false);
  const toastTimer = useRef(null);
  const bumpTimer = useRef(null);

  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    let list = allProducts.filter((p) => {
      const matchCat = category === 'todos' || p.category === category;
      const matchQuery = !q || normalize(`${p.name} ${p.description}`).includes(q);
      return matchCat && matchQuery;
    });
    if (sort === 'menor') list = [...list].sort((a, b) => a.price - b.price);
    if (sort === 'maior') list = [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [query, category, sort]);

  const handleAdd = useCallback(
    (product) => {
      addItem(product);

      setToast({ text: `${product.name} adicionado ao carrinho`, visible: true });
      clearTimeout(toastTimer.current);
      toastTimer.current = setTimeout(() => setToast((t) => ({ ...t, visible: false })), 2200);

      // Reinicia a animação do ícone mesmo em adições consecutivas
      setBump(false);
      clearTimeout(bumpTimer.current);
      requestAnimationFrame(() => {
        setBump(true);
        bumpTimer.current = setTimeout(() => setBump(false), 600);
      });
    },
    [addItem]
  );

  useEffect(
    () => () => {
      clearTimeout(toastTimer.current);
      clearTimeout(bumpTimer.current);
    },
    []
  );

  const goToProducts = () => {
    document.getElementById('produtos')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCategory = (id) => {
    setCategory(id);
    setQuery('');
    goToProducts();
  };

  const handleSearchSubmit = () => {
    setSearchOpen(false);
    setCategory('todos');
    setTimeout(goToProducts, 120);
  };

  const resetFilters = () => {
    setQuery('');
    setCategory('todos');
    setSort('relevancia');
  };

  // Animações de entrada ao rolar a página (reobserva quando a lista de produtos muda)
  useEffect(() => {
    const els = document.querySelectorAll('.reveal:not(.is-visible)');
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('is-visible');
            io.unobserve(e.target);
          }
        }),
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [filtered]);

  return (
    <>
      <Header
        cartCount={count}
        cartBump={bump}
        onOpenCart={() => setCartOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
      />
      <main>
        <Hero />
        <Benefits />
        <Categories onSelect={handleCategory} />
        <Products
          products={filtered}
          query={query}
          setQuery={setQuery}
          category={category}
          setCategory={setCategory}
          sort={sort}
          setSort={setSort}
          onAdd={handleAdd}
          onReset={resetFilters}
        />
        <About />
        <Newsletter />
      </main>
      <Footer />

      <SearchOverlay
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        query={query}
        setQuery={setQuery}
        onSubmit={handleSearchSubmit}
      />

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        items={items}
        total={total}
        count={count}
        changeQty={changeQty}
        removeItem={removeItem}
        clear={clear}
      />

      <div className={`toast ${toast.visible ? 'is-visible' : ''}`} role="status" aria-live="polite">
        <CheckIcon size={18} /> {toast.text}
      </div>
    </>
  );
}
