import { useEffect, useState } from 'react';
import SafeImage from './SafeImage.jsx';
import { CloseIcon, TrashIcon, CartIcon } from './Icons.jsx';
import { formatBRL } from '../utils/helpers.js';

export default function CartDrawer({ open, onClose, items, total, count, changeQty, removeItem, clear }) {
  const [notice, setNotice] = useState(false);

  // Esconde o aviso de demonstração ao fechar a gaveta ou esvaziar o carrinho
  useEffect(() => {
    if (!open || items.length === 0) setNotice(false);
  }, [open, items.length]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  return (
    <>
      <div className={`overlay ${open ? 'is-open' : ''}`} onClick={onClose} aria-hidden="true" />
      <aside
        className={`drawer ${open ? 'is-open' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label="Carrinho de compras"
        aria-hidden={!open}
      >
        <div className="drawer__head">
          <h3>
            Carrinho <span>({count})</span>
          </h3>
          <button className="icon-btn" onClick={onClose} aria-label="Fechar carrinho">
            <CloseIcon />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="drawer__empty">
            <CartIcon size={40} />
            <h4>Seu carrinho está vazio</h4>
            <p>Adicione produtos para vê-los aqui.</p>
            <a href="#produtos" className="btn btn--primary" onClick={onClose}>
              Ver produtos
            </a>
          </div>
        ) : (
          <>
            <ul className="drawer__list">
              {items.map((item) => (
                <li key={item.id} className="line">
                  <SafeImage src={item.image} alt="" className="line__img" />
                  <div className="line__info">
                    <h4>{item.name}</h4>
                    <span>{formatBRL(item.price)}</span>
                    <div className="qty">
                      <button onClick={() => changeQty(item.id, -1)} aria-label="Diminuir quantidade">
                        −
                      </button>
                      <output>{item.qty}</output>
                      <button onClick={() => changeQty(item.id, 1)} aria-label="Aumentar quantidade">
                        +
                      </button>
                    </div>
                  </div>
                  <div className="line__side">
                    <strong>{formatBRL(item.price * item.qty)}</strong>
                    <button
                      className="icon-btn icon-btn--sm"
                      onClick={() => removeItem(item.id)}
                      aria-label={`Remover ${item.name}`}
                    >
                      <TrashIcon />
                    </button>
                  </div>
                </li>
              ))}
            </ul>

            <div className="drawer__foot">
              <div className="drawer__total">
                <span>Total</span>
                <strong>{formatBRL(total)}</strong>
              </div>
              <small>ou 12x de {formatBRL(total / 12)} sem juros</small>
              {notice && (
                <p className="drawer__notice" role="status">
                  A VOLTZ STORE é uma loja de demonstração, então o checkout não está disponível.
                </p>
              )}
              <button className="btn btn--primary btn--block" onClick={() => setNotice(true)}>
                Finalizar compra
              </button>
              <button className="btn btn--text" onClick={clear}>
                Esvaziar carrinho
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
