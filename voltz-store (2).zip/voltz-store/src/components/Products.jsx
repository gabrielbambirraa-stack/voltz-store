import { categories } from '../data/products.js';
import ProductCard from './ProductCard.jsx';
import { SearchIcon } from './Icons.jsx';

const sortOptions = [
  { value: 'relevancia', label: 'Relevância' },
  { value: 'menor', label: 'Menor preço' },
  { value: 'maior', label: 'Maior preço' },
];

export default function Products({
  products,
  query,
  setQuery,
  category,
  setCategory,
  sort,
  setSort,
  onAdd,
  onReset,
}) {
  return (
    <section id="produtos" className="section section--alt">
      <div className="container">
        <div className="section__head reveal">
          <span className="eyebrow">Produtos</span>
          <h2>Seleção VOLTZ</h2>
          <p>Produtos escolhidos a dedo, com os melhores preços da temporada.</p>
        </div>

        <div className="toolbar reveal">
          <div className="toolbar__search">
            <SearchIcon size={18} />
            <input
              type="search"
              placeholder="Buscar produtos..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Buscar produtos"
            />
          </div>

          <div className="chips" role="tablist" aria-label="Filtrar por categoria">
            <button
              className={`chip ${category === 'todos' ? 'is-active' : ''}`}
              onClick={() => setCategory('todos')}
            >
              Todos
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                className={`chip ${category === c.id ? 'is-active' : ''}`}
                onClick={() => setCategory(c.id)}
              >
                {c.name}
              </button>
            ))}
          </div>

          <label className="select">
            <span>Ordenar</span>
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              {sortOptions.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <p className="results-count" aria-live="polite">
          {products.length} {products.length === 1 ? 'produto encontrado' : 'produtos encontrados'}
        </p>

        {products.length > 0 ? (
          <div className="grid">
            {products.map((p, i) => (
              <ProductCard key={p.id} product={p} onAdd={onAdd} index={i} />
            ))}
          </div>
        ) : (
          <div className="empty">
            <h3>Nenhum produto encontrado</h3>
            <p>Tente outro termo de busca ou limpe os filtros.</p>
            <button className="btn btn--primary" onClick={onReset}>
              Limpar filtros
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
