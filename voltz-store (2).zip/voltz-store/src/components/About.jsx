import { TruckIcon, ShieldIcon, CardIcon, HeadsetIcon } from './Icons.jsx';
import SafeImage from './SafeImage.jsx';

const pillars = [
  { icon: <TruckIcon />, title: 'Entrega ágil', text: 'Logística pensada para o seu produto chegar rápido.' },
  { icon: <ShieldIcon />, title: 'Garantia VOLTZ', text: 'Produtos testados e 12 meses de garantia.' },
  { icon: <CardIcon />, title: 'Pague como quiser', text: 'Pix, cartão e parcelamento em até 12x.' },
  { icon: <HeadsetIcon />, title: 'Suporte humano', text: 'Time especialista para tirar suas dúvidas.' },
];

export default function About() {
  return (
    <section id="sobre" className="section">
      <div className="container about">
        <div className="about__media reveal">
          <SafeImage
            src="https://images.unsplash.com/photo-1593642632823-8f785ba67e45?auto=format&fit=crop&w=1000&q=80"
            alt="Setup gamer com monitor e periféricos"
          />
          <div className="about__tag">
            <strong>2026</strong>
            <span>Nova era de setups</span>
          </div>
        </div>

        <div className="about__content">
          <span className="eyebrow reveal">Sobre a VOLTZ</span>
          <h2 className="reveal">Tecnologia que energiza a sua rotina.</h2>
          <p className="reveal">
            A VOLTZ STORE nasceu da vontade de reunir, em um só lugar, periféricos e acessórios que
            unem desempenho, design e boa experiência de uso. Selecionamos cada item pensando em
            quem trabalha, joga e cria todos os dias.
          </p>
          <p className="reveal">
            Nossa proposta é simples: menos ruído, mais qualidade. Um catálogo enxuto, com marcas
            confiáveis, preços justos e atendimento próximo.
          </p>

          <div className="pillars">
            {pillars.map((p, i) => (
              <div key={p.title} className="pillar reveal" style={{ '--d': `${i * 70}ms` }}>
                <span className="pillar__icon">{p.icon}</span>
                <h4>{p.title}</h4>
                <p>{p.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
