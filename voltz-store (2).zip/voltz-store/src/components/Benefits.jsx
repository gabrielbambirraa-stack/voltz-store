import { TruckIcon, ShieldIcon, CardIcon, HeadsetIcon } from './Icons.jsx';

const items = [
  { icon: <TruckIcon size={24} />, title: 'Frete rápido', text: 'Envio para todo o Brasil' },
  { icon: <CardIcon size={24} />, title: '12x sem juros', text: 'No cartão ou 5% off no Pix' },
  { icon: <ShieldIcon size={24} />, title: '12 meses de garantia', text: 'Compra 100% protegida' },
  { icon: <HeadsetIcon size={24} />, title: 'Suporte especializado', text: 'Atendimento de seg. a sáb.' },
];

export default function Benefits() {
  return (
    <section className="benefits" aria-label="Vantagens da loja">
      <ul className="container benefits__list">
        {items.map((b, i) => (
          <li key={b.title} className="benefit reveal" style={{ '--d': `${i * 60}ms` }}>
            <span className="benefit__icon">{b.icon}</span>
            <div>
              <strong>{b.title}</strong>
              <span>{b.text}</span>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
