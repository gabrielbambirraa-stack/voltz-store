import { useEffect, useRef, useState } from 'react';

const fallback =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1a1a1d"/><stop offset="1" stop-color="#2a1608"/></linearGradient></defs><rect width="400" height="300" fill="url(#g)"/><path d="M215 80l-55 85h35l-10 55 60-90h-35z" fill="#ff6a00" opacity=".85"/></svg>`
  );

export default function SafeImage({ src, alt, className = '', ...rest }) {
  const ref = useRef(null);
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);

  // Imagens já em cache podem terminar de carregar antes do React ouvir o evento "load".
  useEffect(() => {
    const el = ref.current;
    if (el && el.complete) {
      if (el.naturalWidth > 0) setLoaded(true);
      else setFailed(true);
    }
  }, [src]);

  return (
    <img
      ref={ref}
      src={failed ? fallback : src}
      alt={alt}
      loading="lazy"
      decoding="async"
      className={`${className} img-fade ${loaded ? 'is-loaded' : ''}`}
      onLoad={() => setLoaded(true)}
      onError={() => {
        setFailed(true);
        setLoaded(true);
      }}
      {...rest}
    />
  );
}
