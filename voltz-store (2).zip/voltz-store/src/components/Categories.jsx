import { categories } from '../data/products.js';
import SafeImage from './SafeImage.jsx';
import { ArrowIcon } from './Icons.jsx';

export default function Categories({ onSelect }) {
  return (
    <section id="categorias" className="section">
      <div className="container">
        <div className="section__head reveal">
          <span className="eyebrow">Categorias</span>
          <h2>Navegue por categoria</h2>
          <p>Tudo o que você precisa para montar o setup ideal.</p>
        </div>

        <div className="cat-grid">
          {categories.map((c, i) => (
            <button
              key={c.id}
              className="cat-card reveal"
              style={{ '--d': `${i * 70}ms` }}
              onClick={() => onSelect(c.id)}
              aria-label={`Ver ${c.name}`}
            >
              <SafeImage src={c.image} alt="" className="cat-card__img" />
              <span className="cat-card__shade" />
              <span className="cat-card__label">
                {c.name}
                <span className="cat-card__arrow">
                  <ArrowIcon size={16} />
                </span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
