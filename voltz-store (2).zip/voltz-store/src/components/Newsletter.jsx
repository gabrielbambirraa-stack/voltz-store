import { useState } from 'react';
import { isValidEmail } from '../utils/helpers.js';
import { CheckIcon } from './Icons.jsx';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('idle'); // idle | error | success

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setStatus('error');
      return;
    }
    setStatus('success');
    setEmail('');
  };

  return (
    <section className="newsletter">
      <div className="container newsletter__inner reveal">
        <div>
          <span className="eyebrow">Newsletter</span>
          <h2>Receba ofertas antes de todo mundo.</h2>
          <p>Cadastre seu e-mail e ganhe 10% de desconto na primeira compra (demonstração).</p>
        </div>

        <form className="newsletter__form" onSubmit={handleSubmit} noValidate>
          <div className="field">
            <input
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (status !== 'idle') setStatus('idle');
              }}
              aria-label="Seu e-mail"
              aria-invalid={status === 'error'}
              className={status === 'error' ? 'has-error' : ''}
            />
            <button type="submit" className="btn btn--primary">
              Cadastrar
            </button>
          </div>
          <p className={`form-msg ${status}`} role="status">
            {status === 'error' && 'Digite um e-mail válido, por exemplo nome@dominio.com.'}
            {status === 'success' && (
              <>
                <CheckIcon size={16} /> Cadastro realizado! Obrigado por se inscrever.
              </>
            )}
          </p>
        </form>
      </div>
    </section>
  );
}
