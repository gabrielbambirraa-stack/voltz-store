import { useEffect, useRef } from 'react';
import { SearchIcon, CloseIcon } from './Icons.jsx';

export default function SearchOverlay({ open, onClose, query, setQuery, onSubmit }) {
  const inputRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const t = setTimeout(() => inputRef.current?.focus(), 60);
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => {
      clearTimeout(t);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  return (
    <div className={`search ${open ? 'is-open' : ''}`} aria-hidden={!open}>
      <div className="search__backdrop" onClick={onClose} />
      <form
        className="search__box"
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit();
        }}
      >
        <SearchIcon size={22} />
        <input
          ref={inputRef}
          type="search"
          placeholder="Busque por fones, teclados, monitores..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Pesquisar produtos"
        />
        <button type="button" className="icon-btn" onClick={onClose} aria-label="Fechar pesquisa">
          <CloseIcon />
        </button>
      </form>
    </div>
  );
}
