import { useEffect, useState } from 'react';
import { BoltIcon, SearchIcon, CartIcon, MenuIcon, CloseIcon } from './Icons.jsx';

const links = [
  { href: '#inicio', label: 'Início' },
  { href: '#produtos', label: 'Produtos' },
  { href: '#categorias', label: 'Categorias' },
  { href: '#sobre', label: 'Sobre' },
];

export default function Header({ cartCount, onOpenCart, onOpenSearch, cartBump }) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen]);

  return (
    <header className={`header ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="container header__inner">
        <a href="#inicio" className="logo" aria-label="VOLTZ STORE - início">
          <span className="logo__mark">
            <BoltIcon size={18} />
          </span>
          <span className="logo__text">
            VOLTZ<span> STORE</span>
          </span>
        </a>

        <nav className={`nav ${menuOpen ? 'is-open' : ''}`} aria-label="Navegação principal">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)}>
              {l.label}
            </a>
          ))}
        </nav>

        <div className="header__actions">
          <button className="icon-btn" onClick={onOpenSearch} aria-label="Pesquisar produtos">
            <SearchIcon />
          </button>
          <button
            className={`icon-btn cart-btn ${cartBump ? 'is-bump' : ''}`}
            onClick={onOpenCart}
            aria-label={`Abrir carrinho, ${cartCount} itens`}
          >
            <CartIcon />
            {cartCount > 0 && <span className="cart-btn__badge">{cartCount}</span>}
          </button>
          <button
            className="icon-btn menu-btn"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
    </header>
  );
}
