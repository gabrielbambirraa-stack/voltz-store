import { heroImage } from '../data/products.js';
import SafeImage from './SafeImage.jsx';
import { ArrowIcon } from './Icons.jsx';

export default function Hero() {
  return (
    <section id="inicio" className="hero">
      <div className="hero__bg">
        <SafeImage src={heroImage} alt="" className="hero__img" loading="eager" />
        <div className="hero__overlay" />
        <div className="hero__grid" />
      </div>

      <div className="container hero__content">
        <span className="eyebrow reveal">Nova coleção 2026</span>
        <h1 className="hero__title reveal" style={{ '--d': '80ms' }}>
          Potência para o <em>seu setup.</em>
        </h1>
        <p className="hero__text reveal" style={{ '--d': '160ms' }}>
          A VOLTZ STORE reúne fones, teclados, mouses e monitores selecionados para quem leva
          performance, design e tecnologia a sério.
        </p>
        <div className="hero__cta reveal" style={{ '--d': '240ms' }}>
          <a href="#produtos" className="btn btn--primary">
            Explorar produtos <ArrowIcon />
          </a>
          <a href="#sobre" className="btn btn--ghost">
            Conheça a VOLTZ
          </a>
        </div>

        <ul className="hero__stats reveal" style={{ '--d': '320ms' }}>
          <li>
            <strong>+120</strong>
            <span>produtos selecionados</span>
          </li>
          <li>
            <strong>12x</strong>
            <span>sem juros</span>
          </li>
          <li>
            <strong>30 dias</strong>
            <span>para trocar</span>
          </li>
        </ul>
      </div>
    </section>
  );
}
