import { useState } from 'react';
import SafeImage from './SafeImage.jsx';
import { CheckIcon } from './Icons.jsx';
import { formatBRL } from '../utils/helpers.js';

export default function ProductCard({ product, onAdd, index }) {
  const [added, setAdded] = useState(false);
  const discount = product.oldPrice
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : 0;

  const handleAdd = () => {
    onAdd(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  };

  return (
    <article className="card reveal" style={{ '--d': `${(index % 4) * 70}ms` }}>
      <div className="card__media">
        <SafeImage src={product.image} alt={product.name} className="card__img" />
        <div className="card__badges">
          {discount > 0 && <span className="badge badge--sale">-{discount}%</span>}
          {product.badge && <span className="badge">{product.badge}</span>}
        </div>
      </div>

      <div className="card__body">
        <h3>{product.name}</h3>
        <p>{product.description}</p>

        <div className="card__price">
          <strong>{formatBRL(product.price)}</strong>
          {product.oldPrice && <s>{formatBRL(product.oldPrice)}</s>}
        </div>
        <span className="card__installments">
          ou 12x de {formatBRL(product.price / 12)}
        </span>

        <button
          className={`btn btn--primary btn--block ${added ? 'is-added' : ''}`}
          onClick={handleAdd}
        >
          {added ? (
            <>
              <CheckIcon /> Adicionado!
            </>
          ) : (
            'Adicionar ao carrinho'
          )}
        </button>
      </div>
    </article>
  );
}
