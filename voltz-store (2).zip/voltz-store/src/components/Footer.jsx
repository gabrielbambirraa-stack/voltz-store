import { BoltIcon, InstagramIcon, YoutubeIcon, XIcon, TiktokIcon } from './Icons.jsx';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <a href="#inicio" className="logo">
            <span className="logo__mark">
              <BoltIcon size={18} />
            </span>
            <span className="logo__text">
              VOLTZ<span> STORE</span>
            </span>
          </a>
          <p>Tecnologia e acessórios premium para o seu setup.</p>
          <div className="socials" aria-label="Redes sociais fictícias">
            <a href="#inicio" aria-label="Instagram (demonstração)"><InstagramIcon /></a>
            <a href="#inicio" aria-label="YouTube (demonstração)"><YoutubeIcon /></a>
            <a href="#inicio" aria-label="X (demonstração)"><XIcon /></a>
            <a href="#inicio" aria-label="TikTok (demonstração)"><TiktokIcon /></a>
          </div>
        </div>

        <nav className="footer__col" aria-label="Links do rodapé">
          <h4>Navegação</h4>
          <a href="#inicio">Início</a>
          <a href="#produtos">Produtos</a>
          <a href="#categorias">Categorias</a>
          <a href="#sobre">Sobre</a>
        </nav>

        <div className="footer__col">
          <h4>Contato <em>(demonstração)</em></h4>
          <span>contato@voltzstore.exemplo</span>
          <span>(00) 0000-0000</span>
          <span>Endereço fictício, 000 — Cidade Exemplo</span>
        </div>
      </div>

      <div className="container footer__bottom">
        <span>© 2026 VOLTZ STORE. Todos os direitos reservados.</span>
        <span>Loja fictícia criada apenas para demonstração.</span>
      </div>
    </footer>
  );
}
