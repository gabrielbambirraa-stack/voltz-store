import { useCallback, useEffect, useMemo, useState } from 'react';

const STORAGE_KEY = 'voltz-store:cart';

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    // Descarta dados corrompidos ou antigos
    return parsed.filter(
      (i) =>
        i &&
        typeof i.id === 'number' &&
        typeof i.name === 'string' &&
        Number.isFinite(i.price) &&
        Number.isInteger(i.qty) &&
        i.qty > 0
    );
  } catch {
    return [];
  }
}

export default function useCart() {
  const [items, setItems] = useState(loadCart);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* armazenamento indisponível */
    }
  }, [items]);

  const addItem = useCallback((product) => {
    setItems((prev) => {
      const found = prev.find((i) => i.id === product.id);
      if (found) return prev.map((i) => (i.id === product.id ? { ...i, qty: i.qty + 1 } : i));
      return [
        ...prev,
        { id: product.id, name: product.name, price: product.price, image: product.image, qty: 1 },
      ];
    });
  }, []);

  const removeItem = useCallback((id) => setItems((prev) => prev.filter((i) => i.id !== id)), []);

  const changeQty = useCallback((id, delta) => {
    setItems((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: i.qty + delta } : i))
        .filter((i) => i.qty > 0)
    );
  }, []);

  const clear = useCallback(() => setItems([]), []);

  const count = useMemo(() => items.reduce((s, i) => s + i.qty, 0), [items]);
  const total = useMemo(() => items.reduce((s, i) => s + i.qty * i.price, 0), [items]);

  return { items, count, total, addItem, removeItem, changeQty, clear };
}
